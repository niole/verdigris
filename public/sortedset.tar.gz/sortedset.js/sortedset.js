"use strict";

(function (global, factory) {
  if (typeof exports === 'object' && typeof module !== 'undefined') {
    module.exports = factory();
  } else if (typeof define === 'function' && define.amd) {
    define(factory);
  } else {
    global.SortedSet = factory();
  }
}(this, function() {

  // Internal private array which holds actual set elements
  var setArray;

  // Constructor for the SortedSet class
  function SortedSet(initial) {
    if (arguments.length > 0) {
      // TODO: Handle the case when initial array is provided; if array has
      // elements of duplicate value, reduce down to one instance and sort the
      // elements in ascending order.
      setArray = [];
      for (var e in initial) {
        if (setArray.indexOf(e) > -1) {
          setArray.push(e);
        }
      }
      setArray.sort();
    } else {
      setArray = [];
    }
  }

  /* Accessor; returns element at index
   */
  SortedSet.prototype.at = function(index) {
    return setArray[index];
  };

  /* Converts a set into an Array and returns the result
   */
  SortedSet.prototype.toArray = function() {
    return setArray.slice(0);
  };

  /* Converts a set into a String and returns the result
   */
  SortedSet.prototype.toString = function() {
    return setArray.toString();
  };

  /* Read-only property for getting number of elements in sorted set
   */
  Object.defineProperty(SortedSet.prototype, 'length', {
    get: function() {
      return setArray.length;
    }
  });

  /* Returns true if a given element exists in the set
   */
  SortedSet.prototype.contains = function(element) {
    // TODO: Implement contains method
    return (setArray.indexOf(element) > -1);
  };

  /* Gets elements between startIndex and endIndex. If endIndex is omitted, a
   * single element at startIndex is returned.
   */
  SortedSet.prototype.get = function(startIndex, endIndex) {
    // TODO: Implement get method
    if (endIndex === null) {
      return setArray[startIndex];
    } else {
      return setArray.slice(startIndex, endIndex);
    }
  };

  /* Gets all items between specified value range. If exclusive is set, values
   * at lower bound and upper bound are not included.
   */
  SortedSet.prototype.getBetween = function(lbound, ubound, exclusive) {
    // TODO: Implement getItemsBetween method
    var i = 0;
    while ((!exclusive && setArray[i] < lbound) || (exclusive && setArray[i] <= lbound)) {
      i += 1;
    }
    var j = i;
    while ((!exclusive && setArray[j] <= ubound) || (exclusive && setArray[j] < ubound)) {
      j += 1;
    }
    return this.get(i,j);
  };

  /* Adds new element to the set if not already in set
   */
  SortedSet.prototype.add = function(element) {
    // TODO: Implement add method
    if (!(this.contains(element))) {
      setArray.push(element);
      setArray.sort();
    }
  };

  /* Removes element from set and returns the element
   */
  SortedSet.prototype.remove = function(element) {
    return this.removeAt(setArray.indexOf(element));
  };

  /* Removes element at index location and returns the element
   */
  SortedSet.prototype.removeAt = function(index) {
    // TODO: Implement removeAt method
    if (index !== 0) {
      var tmp = setArray[0];
      setArray[0] = setArray[index];
      setArray[index] = tmp;
    }
    return setArray.shift();
  };

  /* Removes elements that are larger than lower bound and smaller than upper
   * bound and returns removed elements.
   */
  SortedSet.prototype.removeBetween = function(lbound, ubound, exclusive) {
    var elems = this.get(lbound, ubound, exclusive);
    for (var e in elems) {
      if (e !== null) {
        this.remove(e);
      }
    }
  };

  /* Removes all elements from the set
   */
  SortedSet.prototype.clear = function() {
    setArray = [];
  };

  return SortedSet;
}));
